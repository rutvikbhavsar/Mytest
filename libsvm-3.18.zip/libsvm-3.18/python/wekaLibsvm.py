import subprocess, sys, env
class wekaLibsvm:
    def __init__(self):
        self.folder = env._env['TRAINING_DATA_PATH']        
        self.wekaCommandTraiTestCV = "java -cp weka.jar:libsvm.jar -Djava.awt.headless=true weka.classifiers.functions.LibSVM -S 0 -K 2 -D 3 -G 0.0 -R 0.0 -N 0.5 -M 40.0 -C 1.0 -E 0.001 -P 0.1 -seed 1 -t {} -T {}"
        self.wekaCommandTraiTestP = "java -cp weka.jar:libsvm.jar -Djava.awt.headless=true weka.classifiers.functions.LibSVM -S 0 -K 2 -D 3 -G 0.0 -R 0.0 -N 0.5 -M 40.0 -C 1.0 -E 0.001 -P 0.1 -B -seed 1 -t {} -T {} -p 0"
        self.wekaCommandRemoveFirstAttribute = "java -cp weka.jar:libsvm.jar -Djava.awt.headless=true weka.filters.unsupervised.attribute.Remove -R 1 -i {} -o {}"
        self.wekaCommandFS = 'java -cp weka.jar:libsvm.jar -Djava.awt.headless=true weka.filters.supervised.attribute.AttributeSelection -E "weka.attributeSelection.CfsSubsetEval " -S "weka.attributeSelection.GreedyStepwise -T -1.7976931348623157E308 -N -1" -i {} -o {}'
        self.wekaCommandCV = 'java -cp weka.jar:libsvm.jar -Djava.awt.headless=true weka.classifiers.functions.LibSVM -S 0 -K 2 -D 3 -G 0.0 -R 0.0 -N 0.5 -M 40.0 -C 1.0 -E 0.001 -P 0.1 -t {} -x 10'
        
    def executeWekaCommand(self, inFile, outFile, operation, seqP = {}):
        # Removing first attribute and applying feature selection
        if operation == "fs":
            process = subprocess.Popen(self.wekaCommandRemoveFirstAttribute.format(inFile,self.folder + "/removed.arff"), stderr=subprocess.PIPE, shell=True)
            out, err = process.communicate()
            command = self.wekaCommandFS.format(self.folder + "/removed.arff",outFile)
        elif operation == "traintestp":
            command = self.wekaCommandTraiTestP.format(self.folder + "/" + inFile,self.folder + "/" + outFile)
        elif operation == "traintestcv":
            command = self.wekaCommandTraiTestCV.format(self.folder + "/" + inFile,self.folder + "/" + outFile)
        elif operation == "cv":
            command = self.wekaCommandCV.format(inFile)
        
#         print operation, command
        #"cd "+self.folder+"&"+
        process = subprocess.Popen(command,stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
        out,err = process.communicate()
        
        if operation == "cv":
            print "==========================\n", out
        
        if operation == "traintestcv":
            confusionMatrix = []            
            outLines  = out.split("\n")
            state = False
            for line in outLines:
                if "Error on test data" in line:
                    state = True
                    #print "state changed"                
                if state:
                    #print out                 
                    if "|" in line:                        
                        cmLine = line.split(" ")
                        cmIndex = [index for index in range(len(cmLine)) if cmLine[index].isdigit()]                        
                        confusionMatrix.append([int(cmLine[cmIndex[0]]),int(cmLine[cmIndex[1]])])
                    elif "|" in line:                        
                        cmLine = line.split(" ")
                        cmIndex = [index for index in range(len(cmLine)) if cmLine[index].isdigit()]                        
                        confusionMatrix.append([int(cmLine[cmIndex[0]]),int(cmLine[cmIndex[1]])])
            print "====================================",confusionMatrix,err
            print out
            return confusionMatrix
        elif operation == "traintestp":
           # print "---------out---------------------------\n",out
            if len(out)<2:
                print err
            else:
                outLines  = out.split("\n")
#                 print out
                state = False
                lineCount = 0
                tempCount = 0
                print "sqp len",len(seqP), "outLineslen", len(outLines)
                for line in outLines:
                    if "Predictions on test data" in line:
                        state = True
                    if state and len(line)>1:                        
                        lineSplit = line.split()
#                         print lineSplit
                        #if lineSplit[1] == lineSplit[2] and lineSplit[2] == "1:bright":
                         #   tempCount = tempCount+1
                        if lineSplit[0].isdigit():
#                             print lineSplit[2]
#                             print "seqp",seqP[lineCount], "lineCount", lineCount
                            seqP[lineCount][0].append(lineSplit[2].split(":")[1]) #predicted color
                            seqP[lineCount][1].append(lineSplit[-1] if lineSplit[2] == lineSplit[1] else str((1.0-float(lineSplit[-1])))) #predicted probability FOR GREEN
                            lineCount = lineCount + 1
                print "tempcount",tempCount
                return seqP
                      
                        
