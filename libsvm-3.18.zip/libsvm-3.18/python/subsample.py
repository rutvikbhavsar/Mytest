import svmutil
from svmutil import *
class trySubsample:
    def __init__(self,color):
        self.testFile = os.path.join("C:\\Users\\Sruthi\\Documents\\680\\project\\silver-clusters-master-3way\\silver-clusters-master\\data\\training_data","subsampleTest.csv")
        self.trainFile = os.path.join("C:\\Users\\Sruthi\\Documents\\680\\project\\silver-clusters-master-3way\\silver-clusters-master\\data\\training_data","subsampleTrain.csv")
        self.color = color
        self.tryCurSubsample()
    def getSVMdata(self,filename):
        y = []
        x = []
        with open(filename,"r") as inf:
            for line in inf:
                if len(line.split(",")[0])>4 or line.split(",")[-1] == "class:                    
                    continue                
                curLine = line.split(",")
               # print curLine[-1].rstrip(), self.color, self.color == curLine[-1].rstrip()
                if curLine[-1].rstrip() == self.color:
                    y.append(0)
                else:
                    y.append(1)
                curLine = map(float,curLine[:-30])
                x.append(curLine)
        #print "leny x",len(x)
        #print y
        return y,x
    def tryCurSubsample(self):
        y,x = self.getSVMdata(self.trainFile)
        n,m = self.getSVMdata(self.testFile)        
        for i in range(1):
            model = svmutil.svm_train(y,x,"-b 1")
            p_labs, p_acc, p_vals = svmutil.svm_predict(n, m, model, "-b 1")
            #print "Labels: 0: Green   1: Non green"
            #print "Predicted Labels:",p_labs,"predicted accuracy tuple", p_acc, "probability values",p_vals
            confusionMatrix = [[0,0],[0,0]]
            for iSeq in range(len(n)):
                confusionMatrix[n[iSeq]][int(p_labs[iSeq])] = confusionMatrix[n[iSeq]][int(p_labs[iSeq])] + 1
            print "\t"+self.color+" not "+self.color
            print self.color+"\t", confusionMatrix[0]
            print "not "+ self.color , confusionMatrix[1]
