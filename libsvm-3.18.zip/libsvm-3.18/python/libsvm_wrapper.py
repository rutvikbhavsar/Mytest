# This file is not part of the original libSVM package
import svmutil, wekaLibsvm
import os
from svmutil import *
import csv
import sys
import math, random, numpy as np, itertools
from audioop import avg
import markovClassifier


class libSvmWrapper:
    def __init__(self,classes,tempPath,modelPath,generatecolor,training_file,rowCount,rowCountOffset,randomClassification):
        self.classes = classes
        self.modelPath = modelPath
        self.tempPath = tempPath
        self.generatecolor = generatecolor
        self.training_file = training_file
        self.trainingRowCount = rowCount
        self.rowCountOffset = rowCountOffset
        self.rowCountRange = [range(rowCountOffset[0],sum(rowCount))
                              , range(rowCountOffset[1],rowCountOffset[0])
                              , range(rowCountOffset[2],rowCountOffset[1])
                              , range(rowCountOffset[3],rowCountOffset[2])]
        self.nFold = 5  
        self.confusionMatrix = {}
        self.mConfusionMatrix = {}
        self.balancedIterCount = 1
        self.nObservation = 1
        self.confusionMatrixOVO = []
        self.randomClassification = randomClassification
        self.wekaLibsvm = wekaLibsvm.wekaLibsvm()

    def rowRangeRandom(self, count, rangeValues):
        randomList = []
        random.shuffle(rangeValues)        
        while len(randomList) != count:
            curRangeVal = rangeValues.pop()            
            if curRangeVal not in randomList:
                randomList.append(curRangeVal)
        return randomList

    def randomClasses(self,classList,totalClasses):
        randomList = []
        for i in range(totalClasses):
            randomList.append(random.choice(classList))
        return randomList

    def getNthFold(self, rangeValues, iFold, cvFlag):
        nRows = len(rangeValues)/ self.nFold
        rangeValues.sort()
        if cvFlag:
            curCVSet = set(rangeValues) - set(rangeValues[nRows*iFold:(nRows)*(iFold+1)])
            return list(curCVSet)
        else:
            return rangeValues[nRows*iFold:(nRows)*(iFold+1)]

    def rowRange(self, curColorIndex, cvFlag, cvpFlag, cvSet, iFold, reqRangeIndices, predictCount):
        if (cvFlag == cvpFlag):
            if len(reqRangeIndices) == 0:
                return range(predictCount)
            else:
                return self.rowCountRange[reqRangeIndices[0]] + self.rowCountRange[reqRangeIndices[1]]
        else:
            nthFold = [self.getNthFold(cvSet[0], iFold, cvFlag)
                       , self.getNthFold(cvSet[1], iFold, cvFlag)]
            return nthFold[0] + nthFold[1]

    def readDataFromFile(self, fileName, color, curRange):
        rowCount = 0
        x = []
        y = []
        z = []
        s = []
        with open(fileName, "r") as csvFile:
            reader = csv.reader(csvFile)
            reader.next()            
            for line in reader:                
                if rowCount in curRange:
                    if self.randomClassification:
                            z.append(cvSet[2][curRange.index(rowCount)]) # todo: cvset[2] can be directly accessed after this function call
                    if line[-1].rstrip() == color:                            
                        y.append(0)
                    else:
                        y.append(1)
                    s.append(line[0])                    
                    line = map(float, line[1:-1])                    
                    x.append(line)                    
                rowCount = rowCount + 1            
        return x, y, z, s

            
    def readData(self,fileName, cvSet, color, reqRangeIndices = [], predictCount = 0, cvFlag = False, cvpFlag = False, iFold = 0):
        "Read CSV file into memory for libSVM "                
        curColorIndex = self.classes.index(color)
        curRange = self.rowRange(curColorIndex, cvFlag, cvpFlag, cvSet, iFold, reqRangeIndices, predictCount)            
        curRange.sort()
        x, y, z, s = self.readDataFromFile(fileName, color, curRange)
        return x, y, z, s
        
    def crossValidate(self,trainingCsv,instanceSize = 10000):
        totalRows = 0
        for index in range(len(self.classes)):
            totalRows = totalRows + self.trainingRowCount[index]
        loopCount = self.balancedIterCount
        cmKeys = [','.join(x) for x in itertools.combinations(self.classes, 2)]
        bConMatrix = dict.fromkeys(cmKeys)
        mConMatrix = dict.fromkeys(cmKeys)
        for key in bConMatrix:
            bConMatrix[key] = []
            mConMatrix[key] = []
        bConMatrixRan = dict.fromkeys(cmKeys)
        for key in bConMatrixRan:
            bConMatrixRan[key] = []
        accuracies = dict.fromkeys(cmKeys)
        for key in accuracies:
            accuracies[key] = [[],[]]
        accuraciesRan = dict.fromkeys(cmKeys)
        for key in accuraciesRan:
            accuraciesRan[key] = [[],[]]        
        for iLoop in range(loopCount):
            print "iteration",iLoop
            for curColor, colorIndex, curRowCount in zip(self.classes,range(len(self.classes)),self.trainingRowCount):                                                    
                combinedRangeIndex = [index for index in range(len(self.rowCountRange)) if index!=colorIndex]                
                combinedRangeColor = [self.classes[index] for index in combinedRangeIndex]
                combinedRange = [self.rowCountRange[index] for index in combinedRangeIndex]                
                allRange = list(combinedRange)                
                for allRangeIndex in range(len(allRange)):                    
                    curIterVar =  curColor+","+combinedRangeColor[allRangeIndex]
                    if curIterVar not in cmKeys:
                        continue
                    print curIterVar
                    cvSet = []
                    confusionMatrix = [[0,0],[0,0]]
                    mconfusionMatrix = [[0,0],[0,0]]
                    confusionMatrixRan = [[0,0],[0,0]]
                    curTrainingSetSize = np.amin([instanceSize, len(self.rowCountRange[colorIndex]),len(allRange[allRangeIndex])], axis = 0)
                    curColorRange = list(self.rowCountRange[colorIndex])
                    cvSet.append(self.rowRangeRandom(curTrainingSetSize, list(curColorRange)))                                   
                    cvSet.append(self.rowRangeRandom(curTrainingSetSize, list(allRange[allRangeIndex])))
                    cvSet.append(self.randomClasses([0,1],2*curTrainingSetSize))
                    #print "curTrainingSetSize",curTrainingSetSize,"cvset",cvSet
                    for iRow in range(self.nFold):    
                        x, y, z, s = self.readData(trainingCsv, cvSet, curColor, [], 0, True, False, iRow)                        
                        m, n, o, t = self.readData(trainingCsv, cvSet, curColor, [], 0,False, True, iRow)
                        #print "len x y m n",len(x),len(y),len(m),len(n)
                        self.saveSubsampleToLoadinWeka(x,y,curIterVar.split(",")[0],curIterVar.split(",")[1],"Train")
                        self.saveSubsampleToLoadinWeka(m,n,curIterVar.split(",")[0],curIterVar.split(",")[1],"Test")
                        curCM = self.wekaLibsvm.executeWekaCommand("subsampleTrain.csv","subsampleTest.csv","traintestcv")                        
                        confusionMatrix = self.addMatrices(confusionMatrix,curCM)
                        markov = markovClassifier.MarkovClassifier(curIterVar.split(","))
                        markov.train_model(zip(s, [curIterVar.split(",")[0] if i == 0 else curIterVar.split(",")[1] for i in y]))
                        mcm = markov.test_model(zip(t, [curIterVar.split(",")[0] if i == 0 else curIterVar.split(",")[1] for i in n]))
                        mconfusionMatrix = self.addMatrices(mconfusionMatrix, mcm)
                        if self.randomClassification:
                            self.saveSubsampleToLoadinWeka(x,z,curIterVar.split(",")[0],curIterVar.split(",")[1],"Train")
                            self.saveSubsampleToLoadinWeka(m,o,curIterVar.split(",")[0],curIterVar.split(",")[1],"Test")
                            curRanCM = self.wekaLibsvm.executeWekaCommand("subsampleTrain.csv","subsampleTest.csv","traintestcv")
                            '''if min(min(curRanCM))<1:
                                print curRanCM
                                exit(0)'''
                            confusionMatrixRan = self.addMatrices(confusionMatrixRan,curRanCM)
                    bConMatrix[curIterVar].append(confusionMatrix)
                    mConMatrix[curIterVar].append(mconfusionMatrix)                    
                    if self.randomClassification:
                        bConMatrixRan[curIterVar].append(confusionMatrixRan)
        print "--------", bConMatrix, confusionMatrix
        self.printConfusionMatrix(accuracies, bConMatrix, mConMatrix)
        if self.randomClassification:
            print "\nAfter assigning random samples to same subsamples:"
            self.printConfusionMatrix(accuraciesRan, bConMatrixRan, mConMatrix)

    def trainAndSaveModel(self):
        reqIndices = [index for index in range(len(self.classes)) if self.classes[index]!=self.generatecolor]
        currentColorIndex = self.classes.index(self.generatecolor)
        for index in reqIndices:
            #print "Extracting ---------------------",self.generatecolor,"----",self.classes[index]
            x, y, z, s = self.readData(self.training_file,[], self.generatecolor,[currentColorIndex,index],0)
            print "erunall len",len(y),len(x)
            m = svmutil.svm_train(y, x,"-b 1")
            modelName = self.modelPath+"."+self.generatecolor+self.classes[index]+".model"
            svmutil.svm_save_model(modelName, m)

    def trainAndSaveSubsetforWeka(self,comColor,detachAF):        
        currentColorIndex = self.classes.index(self.generatecolor)
        comColorIndex = self.classes.index(comColor)        
        x, y, z, s = self.readData(self.training_file,[], self.generatecolor,[currentColorIndex,comColorIndex],0)
        if detachAF:            
            for iRow in range(len(x)):
                x[iRow] = x[iRow][:-15]                
        curColorIndices = [index for index in range(len(y)) if y[index] == 0]        
        comColorIndices = [index for index in range(len(y)) if y[index] == 1]        
        trainingSetSize = min(len(curColorIndices),len(comColorIndices))        
        ranCurColorIndices = self.rowRangeRandom(trainingSetSize,curColorIndices)        
        ranComColorIndices = self.rowRangeRandom(trainingSetSize,comColorIndices)        
        xSample = [x[index] for index in ranCurColorIndices]        
        xSample = xSample + [x[index] for index in ranComColorIndices]        
        ySample = [y[index] for index in ranCurColorIndices]
        ySample = ySample + [y[index] for index in ranComColorIndices]        
        self.saveSubsampleToLoadinWeka(xSample,ySample,self.generatecolor,comColor,"Train")  

    def printConfusionMatrix(self, accuracies, bConMatrix, mConMatrix):
        for iCount in range(self.nObservation):
            fScores = {}  
            mfScores = {}          
            for key in bConMatrix:
                self.confusionMatrix[key] = np.mean(np.array(bConMatrix[key][iCount:iCount+1]),axis=0).tolist()
                self.mConfusionMatrix[key] = np.mean(np.array(mConMatrix[key][iCount:iCount+1]),axis=0).tolist()            
            for key in self.confusionMatrix:                        
                curColor = key.split(",")[0]
                allRangeColor = key.split(",")[1]
                print "Confusion Matrix for",curColor,"vs",allRangeColor,":"
                curConfusionMatrix = np.mean(np.array([self.confusionMatrix[key]]),axis=0)#,self.confusionMatrix[allRangeColor+","+curColor] 
                mcurConfusionMatrix = np.mean(np.array([self.mConfusionMatrix[key]]),axis=0)
                #Calculate F-scores
                fs = [0,0]
                mfs = [0,0]
                for k in [0,1]:
                    precision = curConfusionMatrix[k][k]/sum(curConfusionMatrix[k])
                    recall = curConfusionMatrix[k][k]/(curConfusionMatrix[0][k] + curConfusionMatrix[1][k])
                    fs[k] = 2*(precision*recall)/(precision+recall)
                    mprecision = mcurConfusionMatrix[k][k]/sum(mcurConfusionMatrix[k])
                    mrecall = mcurConfusionMatrix[k][k]/(mcurConfusionMatrix[0][k] + mcurConfusionMatrix[1][k])
                    mfs[k] = 2*(mprecision*mrecall)/(mprecision+mrecall)
                fScores[key] = fs
                mfScores[key] = mfs
                confusionMatrixLabels = [curColor,allRangeColor,"Accuracy"]
                cmRow ="{:>10}" * (len(confusionMatrixLabels) + 1)
                print(cmRow.format("", *confusionMatrixLabels))
                confuTotal = [sum(curConfusionMatrix[0]),sum(curConfusionMatrix[1])]
                confuAcc = [curConfusionMatrix[0]/confuTotal[0],curConfusionMatrix[1]/confuTotal[1]]                    
                for label, row,acc,i in zip(confusionMatrixLabels, curConfusionMatrix,confuAcc,[0,1]):
                    accuracies[key][i].append(acc[i]*100)                        
                    print(cmRow.format(label, row[0],row[1],"\t"+str(acc[i]*100)))
                print "F - {}: {}, {}: {}, average: {}".format(key.split(",")[0], fs[0], key.split(",")[1], fs[1], str(sum(fs)/2))            
            print "\n"
            print fScores
            greenf = 0
            redf = 0
            vredf = 0
            greenFs = []
            redFs = []
            vredFs = []
            greenmFs = []
            redmFs = []
            vredmFs = []
            keysg = []
            keysr = []
            keysvr = []
            for key in fScores:
                for color in key.split(","):
                    if color == "green":
                        keysg.append(key)
                        greenFs.append(fScores[key][key.split(",").index(color)])
                        greenmFs.append(mfScores[key][key.split(",").index(color)])
                        greenf += fScores[key][key.split(",").index(color)]
                    if color == "red":
                        keysr.append(key)
                        redFs.append(fScores[key][key.split(",").index(color)])
                        redmFs.append(mfScores[key][key.split(",").index(color)])
                        redf += fScores[key][key.split(",").index(color)]
                    if color == "vred":
                        keysvr.append(key)
                        vredFs.append(fScores[key][key.split(",").index(color)])
                        vredmFs.append(mfScores[key][key.split(",").index(color)])
                        vredf += fScores[key][key.split(",").index(color)]
#             print keysr, "avg"
#             print ",".join(map(str, redFs)), ",", greenf/3
#             print keysg, "avg"
#             print ",".join(map(str,greenFs)), ",", greenf/3
#             print keysvr, "avg"
#             print ",".join(map(str,vredFs)), ",", vredf/3
            with open("comparison.csv","a") as f:
                f.write("green," + ",".join(map(str,greenFs))+ ","+ str(greenf/3)+
                        ",,red," + ",".join(map(str,redFs))+ ","+ str(redf/3)+ 
                        ",,vred," + ",".join(map(str,vredFs))+ ","+ str(vredf/3) +
                        ",,green m," + ",".join(map(str,greenmFs)) +
                        ",,red m," + ",".join(map(str,redmFs)) +
                        ",,vred m," + ",".join(map(str,vredmFs))+","
                        )
            
                #print "green in green vs dark",accuracies["dark,green"][0]
                #print "green in red vs green",accuracies["red,green"][1]

    def saveSubsampleToLoadinWeka(self,x,y,curColor,comColor,setType):
        filename = os.path.normpath(os.path.join("/".join(self.modelPath.split("/")[:-2]), "training_data/subsample" + setType +".csv"))
        print "filename:",filename
        with open(filename,"w") as outf:
            print "xlen",len(x)
            print "len0",len(x[0])
            for motifIndex in range(len(x[0])):
                outf.write("Motif" + str(motifIndex) +",")
            outf.write("Class\n")
            for lineIndex in range(len(x)):
                curClass = comColor if y[lineIndex] else curColor
                outf.write(",".join( str(value) for value in x[lineIndex]) + "," + curClass +"\n")

    def addMatrices(self,leftMatrix,rightMatrix):
        #print "adding",leftMatrix,rightMatrix
	temp = [[0 for row in range(len(leftMatrix[0]))] for column in range(len(leftMatrix))]
	for rowIndex in range(len(leftMatrix)):
		for columnIndex in range(len(leftMatrix[0])):
			temp[rowIndex][columnIndex] = leftMatrix[rowIndex][columnIndex] + rightMatrix[rowIndex][columnIndex]
        #print "tenp ---------------------------------------------",temp			
	return temp
    
    def cross(self, trainingFile):
        self.wekaLibsvm.executeWekaCommand(trainingFile,"","cv")    
                
if __name__ == "__main__":     
    featureFile = sys.argv[1]
    x, y = readData(featureFile)
    m = svm_train(y, x, '-v 10')
